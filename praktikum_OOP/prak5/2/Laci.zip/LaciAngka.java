public class LaciAngka<T extends Number> extends Laci<T> { 
    public LaciAngka(String label){ 
        super(label); 
    } 

    public double total(){ 
        double sum = 0; 
        for (int i = 0; i < items.size(); i++){
            sum += items.get(i).doubleValue();
        }
        return sum; 
    }

    public double rataRata(){
        if (items.size() != 0){
            return total() / items.size(); 
        }
        return 0.0;
    }

}