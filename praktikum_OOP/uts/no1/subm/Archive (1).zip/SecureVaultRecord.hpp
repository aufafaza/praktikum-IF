#ifndef SECURE_VAULT_RECORD_HPP
#define SECURE_VAULT_RECORD_HPP

#include "BaseRecord.hpp"

class SecureVaultRecord : protected BaseRecord{ 
public: 
    SecureVaultRecord(std::string author, int key); 
    ~SecureVaultRecord() override; 
    // int calculateClearance() const override; 
};

#endif
