#include "CloudNode.hpp"
#include "Formatter.hpp"
#include <string> 

using namespace std; 
CloudNode::CloudNode(string name, int lim) : server_name(name), limit_gb(lim), used_gb(0) {
    Formatter::printCtor(server_name);
}; 

CloudNode::CloudNode(const CloudNode& other) : CloudNode(other.server_name, other.limit_gb){
    Formatter::printCCtor(other.server_name);
};

CloudNode::~CloudNode() {
    Formatter::printDtor(server_name);
}

CloudNode CloudNode::operator=(const CloudNode& other){
    Formatter::printAssign(server_name);
    if (other.getUsedGB() + 2 <= this->limit_gb){
        this->used_gb = std::move(other.getUsedGB() + 2);
    }
    return *this;
}
CloudNode CloudNode::operator+(int n){
    this->limit_gb+=n;
    return CloudNode(server_name, limit_gb);
}

CloudNode CloudNode::operator-(int n){
    this->limit_gb-=n;

    return CloudNode(server_name, limit_gb);

}

void systemWipe(CloudNode &node){
        node.used_gb = 0; 
        node.limit_gb = 0;
}