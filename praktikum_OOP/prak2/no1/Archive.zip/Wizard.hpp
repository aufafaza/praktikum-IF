#include "Maiar.hpp" 

class Wizard : private Maiar { 
	private: 
		string staffName;
	public:
		Wizard(string name, int hp, int power,  string staffName);
		~Wizard(); 
		void describe() const; 
		void cast(); 
};	 


